package com.example.lab3_mob403.bai4;

import com.example.lab3_mob403.Model.AndroidVersion;

public class JSONResponse4 {
    private AndroidVersion[] android;
    public AndroidVersion[] getAndroid() { return android;
    }
}
