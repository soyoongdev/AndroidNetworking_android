package com.example.lab3_mob403.bai3;

import com.example.lab3_mob403.Model.AndroidVersion;

public class JSONResponse {
    private AndroidVersion[] android;
    public AndroidVersion[] getAndroid() { return android;
    }
}
